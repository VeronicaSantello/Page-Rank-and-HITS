@authors: Bison Gianluca (870028) - Rossato Davide (870530) - Santello Veronica (870320)

@date: 29/07/21

@brief: Information Retrieval and Web Search Projects

@folder:

	-  main project:	 c++ code for our project without sampling (classical version)
		-  the MakeFile is in this path: .\main project\cmake-build-debug
		-  the graph roadNet-TX used is in this path .\main project\cmake-build-debug\grafi

	-  sampling project: 	 c++ code for our project with sampling
		-  the MakeFile is in this path: .\sampling project\cmake-build-debug
		-  the graph roadNet-TX used is in this path .\sampling project\cmake-build-debug\grafi
	
	-  report and misc:	folder which contains docs and dataset
		-  analysis.ipynb: Jupyter Notebook with visual analysis of data in python
		-  report_irws.pdf: pdf report
 		-  dataset.csv: data produced for the analysis